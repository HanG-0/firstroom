#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "SDL2/SDL_ttf.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <setjmp.h>

#define ADD 10
void LOAD_BEST();
void LOAD();
void QUIT();
void JUMP();
void BUMP();
void PRINTSCORE();
void Obstacle();
void DOWN();
void Bird();

SDL_Window *Window = NULL;     // 窗口(均为加载函数)
SDL_Renderer *Renderer = NULL; // 画笔（渲染）

// 主界面
SDL_Surface *MainBackGroundSurface = NULL; // 图形
SDL_Texture *MainBackGroundTexture = NULL; // 纹理
SDL_Rect MainBackGroundRect;               // 纹理的信息（长宽高）
// 在play界面
SDL_Surface *PlayBackGroundSurface = NULL;
SDL_Texture *PlayBackGroundTexture = NULL;
SDL_Rect PlayBackGroundRect;
// play界面的云彩
SDL_Surface *UpBackGroundSurface = NULL;
SDL_Texture *UpBackGroundTexture = NULL;
SDL_Rect UpBackGroundRect;
// 小dino
SDL_Surface *DinoSurface = NULL;
SDL_Texture *DinoTexture = NULL;
SDL_Rect DinoRect;
// 小dino（抬左脚）
SDL_Surface *Dino_LeftSurface = NULL;
SDL_Texture *Dino_LeftTexture = NULL;
SDL_Rect Dino_LeftRect;
// 小dino（抬右脚）
SDL_Surface *Dino_RightSurface = NULL;
SDL_Texture *Dino_RightTexture = NULL;
SDL_Rect Dino_RightRect;
// 计分字体
TTF_Font *ScoreFont = NULL;       // 字体本身
SDL_Surface *ScoreSurface = NULL; // 理同图片，为了字体能被打印出来
SDL_Texture *ScoreTexture = NULL;
SDL_Rect ScoreRect;
SDL_Color FontColor = {0, 0, 0, 0}; // 字体颜色 r g b a
// 结束字体1
TTF_Font *OverFont = NULL;
SDL_Surface *OverFontSurface = NULL;
SDL_Texture *OverFontTexture = NULL;
SDL_Rect OverFontRect;
SDL_Color OverFontColor = {0, 0, 0, 0};
// 结束字体2
TTF_Font *EndFont = NULL;
SDL_Surface *EndFontSurface = NULL;
SDL_Texture *EndFontTexture = NULL;
SDL_Rect EndFontRect;
SDL_Color EndFontColor = {200, 0, 0, 0};
// 最好成绩字体
TTF_Font *BestFont = NULL;
SDL_Surface *BestFontSurface = NULL;
SDL_Texture *BestFontTexture = NULL;
SDL_Rect BestFontRect;
SDL_Color BestFontColor = {200, 0, 0, 0};
// 开始界面字体
TTF_Font *StartFont = NULL;
SDL_Surface *StartFontSurface = NULL;
SDL_Texture *StartFontTexture = NULL;
SDL_Rect StartFontRect;
SDL_Color StartFontColor = {200, 0, 0, 0};
// 仙人掌low_1
SDL_Surface *ObstacleSurface = NULL;
SDL_Texture *ObstacleTexture = NULL;
SDL_Rect ObstacleRect;
// 仙人掌Low_2
SDL_Surface *Low_2Surface = NULL;
SDL_Texture *Low_2Texture = NULL;

// 仙人掌Low_3
SDL_Surface *Low_3Surface = NULL;
SDL_Texture *Low_3Texture = NULL;

// 仙人掌High_1
SDL_Surface *High_1Surface = NULL;
SDL_Texture *High_1Texture = NULL;

// 仙人掌High_2
SDL_Surface *High_2Surface = NULL;
SDL_Texture *High_2Texture = NULL;

// 仙人掌Four
SDL_Surface *FourSurface = NULL;
SDL_Texture *FourTexture = NULL;

// 小鸟（up）
SDL_Surface *BirdUpSurface = NULL;
SDL_Texture *BirdUpTexture = NULL;
SDL_Rect BirdUpRect;
// 小鸟（down）
SDL_Surface *BirdDownSurface = NULL;
SDL_Texture *BirdDownTexture = NULL;
SDL_Rect BirdDownRect;
// dino  down（抬左脚）
SDL_Surface *DinoDown_LeftSurface = NULL;
SDL_Texture *DinoDown_LeftTexture = NULL;
SDL_Rect DinoDown_LeftRect;
// dino down（抬右脚）
SDL_Surface *DinoDown_RightSurface = NULL;
SDL_Texture *DinoDown_RightTexture = NULL;
SDL_Rect DinoDown_RightRect;

// 左右脚转换的过渡纹理
SDL_Texture *Temp = NULL;
SDL_Texture *TempForDown = NULL;
SDL_Texture *TempForBird = NULL;
SDL_Rect TempForBird_Rect;
// 用于不同障碍的转换过渡纹理，矩形
SDL_Texture *TempForObstacle = NULL;
SDL_Rect TempForObstacle_Rect;
// 结束图标
SDL_Surface *RestartSurface = NULL;
SDL_Texture *RestartTexture = NULL;
SDL_Rect RestartRect;
//  重新开始
jmp_buf again;
// 计时器
Uint32 start = 0; // 计时器启动时间
Uint32 now = 0;
Uint32 jump_start = 0;
Uint32 jump_now = 0;

double speed = 1.0; // 游戏速度
int i = 0;          // i%2判断左右脚
int b = 0;          // b%2判断上下翼
double BackGroundMove = 0;
double UpGroundMove = 0;
double ObstacleMove = 640;
double BirdMove = -80;
double a = 190.0; // 在jump（）中用到的参数
int random;       // 随机数
bool the_jump_from_obstacle = false;
bool the_down_from_obstacle = false;
char record_time[30] = "Score:";
char record_best[30] = "Best ";
int record_best_int = 0;
int Obstacle_type = 0;
int return_longjump = 0;
FILE *file_1;

SDL_Event MainEvent; // 主事件（接下来基本操作都在这下面进行）

int SDL_main(int argc, char *argv[])
{ // 在sdl的世界里，main函数注意语法
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();
    // 字体初始化
    Window = SDL_CreateWindow("Dino! Dino!", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 655, 280, SDL_WINDOW_SHOWN); // 参数分别为 字符串显示标题 （int）窗口x坐标 （int）y坐标 （int）宽度 （int）高度 显示窗口的标记 //
    // DL_WINDOWPOS_CENTERED意为窗口在正中间
    Renderer = SDL_CreateRenderer(Window, -1, SDL_RENDERER_ACCELERATED);
    // 使画笔定向到窗口：创造画笔的函数（位置在窗口，目录为-1，硬件加速（用显卡））
    LOAD();                    // 加载图片
    SDL_RenderClear(Renderer); // 清空画笔
    SDL_RenderCopy(Renderer, MainBackGroundTexture, NULL, &MainBackGroundRect);
    SDL_RenderCopy(Renderer, StartFontTexture, NULL, &StartFontRect);
    SDL_RenderPresent(Renderer); // 画笔显示copy的内容
    while (SDL_WaitEvent(&MainEvent))
    { // waitevent：sdl判断语句，有操作返回1，除非sdl——quit，不然一直等待操作
        switch (MainEvent.type)
        {

        case SDL_QUIT: // 点击退出
            QUIT();
        case SDL_KEYDOWN: // 键盘交互
            switch (MainEvent.key.keysym.sym)
            {
            case SDLK_SPACE:                     // 如果按下space键
                return_longjump = setjmp(again); // 从此处重新开始
                if (return_longjump)
                    fclose(file_1);
                BirdMove = -80; // 初始化鸟的位置
                ObstacleMove = 640;
                the_jump_from_obstacle = false;
                the_down_from_obstacle = false;
                start = SDL_GetTicks(); // 记录开始时间
                LOAD_BEST();
                while (1)
                {
                    now = SDL_GetTicks();
                    speed = (now - start) / 100000.0;
                    PlayBackGroundRect.x = BackGroundMove; // 地面的矩形
                    PlayBackGroundRect.y = 220;
                    PlayBackGroundRect.h = PlayBackGroundSurface->h;
                    PlayBackGroundRect.w = PlayBackGroundSurface->w;

                    UpBackGroundRect.x = UpGroundMove; // 云朵背景的矩形
                    UpBackGroundRect.y = -15;
                    UpBackGroundRect.h = UpBackGroundSurface->h;
                    UpBackGroundRect.w = UpBackGroundSurface->w;

                    i++;
                    if (i % 2 == 0)
                        Temp = Dino_RightTexture; // 左右脚的过渡
                    else if (i % 2 == 1)
                        Temp = Dino_LeftTexture;
                    PRINTSCORE(); // 得到目前的分数

                    SDL_RenderClear(Renderer); // 清空画笔
                    SDL_RenderCopy(Renderer, PlayBackGroundTexture, NULL, &PlayBackGroundRect);
                    SDL_RenderCopy(Renderer, UpBackGroundTexture, NULL, &UpBackGroundRect);
                    SDL_RenderCopy(Renderer, ScoreTexture, NULL, &ScoreRect);       // 文字
                    SDL_RenderCopy(Renderer, BestFontTexture, NULL, &BestFontRect); // 文字
                    SDL_RenderCopy(Renderer, Temp, NULL, &Dino_LeftRect);
                    SDL_RenderPresent(Renderer); // 绘图
                    BackGroundMove -= 10 * (speed + 1);
                    UpGroundMove -= 4 * (speed + 1);

                    Sleep(40);
                    if (PlayBackGroundRect.x < -860)
                        BackGroundMove = 0;
                    if (UpBackGroundRect.x < -784)
                        UpGroundMove = 0;
                    SDL_PollEvent(&MainEvent);
                    switch (MainEvent.type)
                    {
                    case SDL_QUIT:
                        QUIT();
                        break;
                    case SDL_KEYDOWN:
                        switch (MainEvent.key.keysym.sym)
                        {
                        case SDLK_UP:
                            JUMP();
                            break;
                        case SDLK_SPACE:
                            JUMP();
                            break;
                        case SDLK_DOWN:
                            DOWN();
                            break;
                        default:
                            SDL_PeepEvents(&MainEvent, 100, SDL_GETEVENT, SDL_FIRSTEVENT, SDL_LASTEVENT);
                            break;
                        }
                        break;
                    case SDL_KEYUP:
                        SDL_PeepEvents(&MainEvent, 100, SDL_GETEVENT, SDL_FIRSTEVENT, SDL_LASTEVENT);
                        break;
                    default:
                        break;
                    }
                    srand((unsigned)time(NULL) + (unsigned)rand());
                    random = rand() % 6;
                    if (random == 3)
                        Obstacle();
                    srand((unsigned)time(NULL) + (unsigned)rand());
                    random = rand() % 10;
                    if (random == 4)
                        Bird();
                }
            default:
                break;
            }
            break;
        case SDL_MOUSEBUTTONDOWN:                                        // 鼠标点下去按钮时
            printf("(%d,%d)\n", MainEvent.button.x, MainEvent.button.y); // 打印鼠标坐标（在命令行），变量来自于头文件
            break;
        default:
            break;
        }
    }
    QUIT(); // 相当于return 0;
}
void QUIT() // 退出
{

    SDL_FreeSurface(MainBackGroundSurface);
    SDL_FreeSurface(PlayBackGroundSurface);
    SDL_FreeSurface(UpBackGroundSurface);
    SDL_FreeSurface(ScoreSurface);
    SDL_FreeSurface(DinoSurface);
    SDL_FreeSurface(Dino_LeftSurface);
    SDL_FreeSurface(DinoDown_LeftSurface);
    SDL_FreeSurface(Dino_RightSurface);
    SDL_FreeSurface(DinoDown_RightSurface);
    SDL_FreeSurface(ObstacleSurface);
    SDL_FreeSurface(High_1Surface);
    SDL_FreeSurface(High_2Surface);
    SDL_FreeSurface(Low_2Surface);
    SDL_FreeSurface(Low_3Surface);
    SDL_FreeSurface(FourSurface);
    SDL_FreeSurface(BirdUpSurface);
    SDL_FreeSurface(BirdDownSurface);
    SDL_FreeSurface(OverFontSurface);
    SDL_FreeSurface(BestFontSurface);
    SDL_FreeSurface(StartFontSurface);
    SDL_FreeSurface(EndFontSurface);
    SDL_FreeSurface(RestartSurface);
    // destroy相当于free，你的主背景，play界面背景，画笔，字体，都要记得free
    SDL_DestroyRenderer(Renderer); //
    SDL_DestroyTexture(MainBackGroundTexture);
    SDL_DestroyTexture(PlayBackGroundTexture);
    SDL_DestroyTexture(UpBackGroundTexture);
    SDL_DestroyTexture(ScoreTexture);
    SDL_DestroyTexture(OverFontTexture);
    SDL_DestroyTexture(BestFontTexture);
    SDL_DestroyTexture(StartFontTexture);
    SDL_DestroyTexture(EndFontTexture);
    SDL_DestroyTexture(RestartTexture);
    TTF_CloseFont(ScoreFont); // 消除字体
    TTF_CloseFont(OverFont);
    TTF_CloseFont(BestFont);
    TTF_CloseFont(StartFont);
    TTF_CloseFont(EndFont);
    SDL_DestroyWindow(Window);
    SDL_DestroyTexture(DinoTexture);
    SDL_DestroyTexture(Dino_LeftTexture);
    SDL_DestroyTexture(DinoDown_LeftTexture);
    SDL_DestroyTexture(Dino_RightTexture);
    SDL_DestroyTexture(DinoDown_RightTexture);
    SDL_DestroyTexture(ObstacleTexture);
    SDL_DestroyTexture(High_1Texture);
    SDL_DestroyTexture(High_2Texture);
    SDL_DestroyTexture(Low_2Texture);
    SDL_DestroyTexture(Low_3Texture);
    SDL_DestroyTexture(FourTexture);
    SDL_DestroyTexture(BirdUpTexture);
    SDL_DestroyTexture(BirdDownTexture);
    SDL_DestroyTexture(Temp);
    SDL_DestroyTexture(TempForDown);
    SDL_DestroyTexture(TempForBird);
    SDL_DestroyTexture(TempForObstacle);
    record_best_int = atoi(record_best + 11); // 将字符串数字变为整形，方便比较
    if (record_best_int < ((now - start) / 100))
    {
        rewind(file_1);
        fputs(record_time, file_1);
    }
    fclose(file_1);
    SDL_Quit();
}
void LOAD()
{                                                                                          // 加载图片
    MainBackGroundSurface = IMG_Load("MainSurface.png");                                   // 从该文件夹中，加载图片文件到mainbackgroundsurface，双引号内是图片名称
    MainBackGroundTexture = SDL_CreateTextureFromSurface(Renderer, MainBackGroundSurface); // 将图片转化为纹理，将纹理绑定到画笔上，这样画笔可以画纹理
    MainBackGroundRect.x = 0;                                                              // 定义有关信息
    MainBackGroundRect.y = 0;                                                              // 图片的左上角坐标
    MainBackGroundRect.h = MainBackGroundSurface->h;
    MainBackGroundRect.w = MainBackGroundSurface->w;
    // 加载play界面
    PlayBackGroundSurface = IMG_Load("PlaySurface.png");
    PlayBackGroundTexture = SDL_CreateTextureFromSurface(Renderer, PlayBackGroundSurface);
    // 加载play界面的云彩
    UpBackGroundSurface = IMG_Load("Up_BackGround.png");
    UpBackGroundTexture = SDL_CreateTextureFromSurface(Renderer, UpBackGroundSurface);
    // 加载小dino的图片
    DinoSurface = IMG_Load("Dino.png");
    DinoTexture = SDL_CreateTextureFromSurface(Renderer, DinoSurface);
    // 加载小dino(抬左脚)的图片
    Dino_LeftSurface = IMG_Load("Dino_left_up.png");
    Dino_LeftTexture = SDL_CreateTextureFromSurface(Renderer, Dino_LeftSurface);
    Dino_LeftRect.x = 0;
    Dino_LeftRect.y = 190;
    Dino_LeftRect.h = Dino_LeftSurface->h;
    Dino_LeftRect.w = Dino_LeftSurface->w;
    // 加载小dino（抬右脚）的图片
    Dino_RightSurface = IMG_Load("Dino_right_up.png");
    Dino_RightTexture = SDL_CreateTextureFromSurface(Renderer, Dino_RightSurface);
    Dino_RightRect.x = 0;
    Dino_RightRect.y = 190;
    Dino_RightRect.h = Dino_RightSurface->h;
    Dino_RightRect.w = Dino_RightSurface->w;
    // 加载dino down(抬左脚)的图片
    DinoDown_LeftSurface = IMG_Load("DinoDown_Left.png");
    DinoDown_LeftTexture = SDL_CreateTextureFromSurface(Renderer, DinoDown_LeftSurface);
    DinoDown_LeftRect.x = 0;
    DinoDown_LeftRect.y = 218;
    DinoDown_LeftRect.h = DinoDown_LeftSurface->h;
    DinoDown_LeftRect.w = DinoDown_LeftSurface->w;
    // 加载小dino Down(抬左脚)的图片
    DinoDown_RightSurface = IMG_Load("DinoDown_Right.png");
    DinoDown_RightTexture = SDL_CreateTextureFromSurface(Renderer, DinoDown_RightSurface);
    DinoDown_RightRect.x = 0;
    DinoDown_RightRect.y = 218;
    DinoDown_RightRect.h = DinoDown_RightSurface->h;
    DinoDown_RightRect.w = DinoDown_RightSurface->w;
    // 加载仙人掌图片
    ObstacleSurface = IMG_Load("Obstacle.png");
    ObstacleTexture = SDL_CreateTextureFromSurface(Renderer, ObstacleSurface);
    // 加载仙人掌图片Low_2
    Low_2Surface = IMG_Load("Low_2.png");
    Low_2Texture = SDL_CreateTextureFromSurface(Renderer, Low_2Surface);
    // 加载仙人掌图片Low_3
    Low_3Surface = IMG_Load("Low_3.png");
    Low_3Texture = SDL_CreateTextureFromSurface(Renderer, Low_3Surface);
    // 加载仙人掌图片High_1
    High_1Surface = IMG_Load("High_1.png");
    High_1Texture = SDL_CreateTextureFromSurface(Renderer, High_1Surface);
    // 加载仙人掌图片High_2
    High_2Surface = IMG_Load("High_2.png");
    High_2Texture = SDL_CreateTextureFromSurface(Renderer, High_2Surface);
    // 加载仙人掌图片Four
    FourSurface = IMG_Load("Four.png");
    FourTexture = SDL_CreateTextureFromSurface(Renderer, FourSurface);
    // 加载bird up图片
    BirdUpSurface = IMG_Load("Bird_Up.png");
    BirdUpTexture = SDL_CreateTextureFromSurface(Renderer, BirdUpSurface);
    // 加载bird down图片
    BirdDownSurface = IMG_Load("Bird_Down.png");
    BirdDownTexture = SDL_CreateTextureFromSurface(Renderer, BirdDownSurface);
    // 加载字体
    ScoreFont = TTF_OpenFont("visitor1.ttf", 50); // 打开字体文件，前面是文件名
    OverFont = TTF_OpenFont("visitor1.ttf", 50);
    // 加载结束界面的提示语
    EndFont = TTF_OpenFont("visitor1.ttf", 50);
    EndFontSurface = TTF_RenderUTF8_Blended(EndFont, "(Press Space to Restart)", EndFontColor);
    EndFontTexture = SDL_CreateTextureFromSurface(Renderer, EndFontSurface);
    EndFontRect.x = 130;
    EndFontRect.y = 140;
    EndFontRect.w = 310;
    EndFontRect.h = 40;
    // 加载开始界面的提示语
    StartFont = TTF_OpenFont("visitor1.ttf", 50);
    StartFontSurface = TTF_RenderUTF8_Blended(StartFont, "=>Press Space to Start", StartFontColor);
    StartFontTexture = SDL_CreateTextureFromSurface(Renderer, StartFontSurface);
    StartFontRect.x = 80;
    StartFontRect.y = 23;
    StartFontRect.w = 300;
    StartFontRect.h = 50;
    // 加载结束图标
    RestartSurface = IMG_Load("Restart.png");
    RestartTexture = SDL_CreateTextureFromSurface(Renderer, RestartSurface);
    RestartRect.x = 220;
    RestartRect.y = 180;
    RestartRect.h = RestartSurface->h;
    RestartRect.w = RestartSurface->w;
}
void BUMP()
{

    ScoreRect.x = 410; // 画的位置
    ScoreRect.y = 100;
    ScoreRect.w = 150; //(矩形h w控制字体大小)
    ScoreRect.h = 30;

    OverFontSurface = TTF_RenderUTF8_Blended(OverFont, "Game Over", OverFontColor); // 从左到右：字体，要打的字符串，字体颜色  存到一个图片里去
    OverFontTexture = SDL_CreateTextureFromSurface(Renderer, OverFontSurface);
    OverFontRect.x = 90; // 画的位置
    OverFontRect.y = 85;
    OverFontRect.w = 370; //(矩形h w控制字体大小)
    OverFontRect.h = 45;
    SDL_RenderCopy(Renderer, OverFontTexture, NULL, &OverFontRect);
    SDL_RenderCopy(Renderer, EndFontTexture, NULL, &EndFontRect);
    SDL_RenderCopy(Renderer, RestartTexture, NULL, &RestartRect);
    SDL_RenderPresent(Renderer);
    record_best_int = atoi(record_best + 11); // 将字符串数字变为整形，方便比较
    if (record_best_int < ((now - start) / 100))
    {
        rewind(file_1);
        fputs(record_time, file_1);
    }
    while (SDL_WaitEvent(&MainEvent))
    {
        switch (MainEvent.type)
        {
        case SDL_KEYDOWN:
            switch (MainEvent.key.keysym.sym)
            {
            case SDLK_SPACE:

                longjmp(again, 1);
                break;
            default:
                break;
            }
            break;
        case SDL_QUIT:
            QUIT();
        default:
            break;
        case SDL_MOUSEBUTTONUP:
            if (MainEvent.button.x > RestartRect.x && MainEvent.button.x < RestartRect.x + RestartRect.w && MainEvent.button.y > RestartRect.y && MainEvent.button.y < RestartRect.y + RestartRect.h)
                longjmp(again, 1);
            break;
        }
    }

    return;
}
void PRINTSCORE()
{
    now = SDL_GetTicks();
    sprintf(record_time + 6, "%d", (now - start) / 100);
    ScoreSurface = TTF_RenderUTF8_Blended(ScoreFont, record_time, FontColor); // 从左到右：字体，要打的字符串，字体颜色  存到一个图片里去
    ScoreTexture = SDL_CreateTextureFromSurface(Renderer, ScoreSurface);
    ScoreRect.x = 510; // 画的位置
    ScoreRect.y = 25;
    ScoreRect.w = 130; //(矩形h w控制字体大小)
    ScoreRect.h = 35;
}
void JUMP()
{
    jump_start = SDL_GetTicks();
    double V0 = 42;
    double t = 0;
    for (a = 190.0; a <= 190 && a > -90;)
    {
        jump_now = SDL_GetTicks();
        speed = (jump_now - start) / 100000.0;
        PlayBackGroundRect.x = BackGroundMove; // 定义有关信息
        PlayBackGroundRect.y = 220;            // 图片的左上角坐标
        PlayBackGroundRect.h = PlayBackGroundSurface->h;
        PlayBackGroundRect.w = PlayBackGroundSurface->w;

        UpBackGroundRect.x = UpGroundMove; // 云朵背景的矩形
        UpBackGroundRect.y = -15;
        UpBackGroundRect.h = UpBackGroundSurface->h;
        UpBackGroundRect.w = UpBackGroundSurface->w;

        DinoRect.x = 0; // 恐龙位置
        DinoRect.y = a;
        DinoRect.h = DinoSurface->h;
        DinoRect.w = DinoSurface->w;

        BirdUpRect.x = BirdMove; // 小鸟坐标
        BirdUpRect.y = 130 + random;
        BirdUpRect.h = BirdUpSurface->h;
        BirdUpRect.w = BirdUpSurface->w;
        BirdDownRect.x = BirdMove;
        BirdDownRect.y = 138 + random;
        BirdDownRect.h = BirdDownSurface->h;
        BirdDownRect.w = BirdDownSurface->w;

        if (Obstacle_type == 0)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 220;
            TempForObstacle_Rect.h = ObstacleSurface->h;
            TempForObstacle_Rect.w = ObstacleSurface->w;
            TempForObstacle = ObstacleTexture;
        }
        else if (Obstacle_type == 1)
        {
            TempForObstacle_Rect.x = ObstacleMove; //
            TempForObstacle_Rect.y = 220;
            TempForObstacle_Rect.h = Low_2Surface->h;
            TempForObstacle_Rect.w = Low_2Surface->w;
            TempForObstacle = Low_2Texture;
        }
        else if (Obstacle_type == 2)
        {
            TempForObstacle_Rect.x = ObstacleMove; //
            TempForObstacle_Rect.y = 220;
            TempForObstacle_Rect.h = Low_3Surface->h;
            TempForObstacle_Rect.w = Low_3Surface->w;
            TempForObstacle = Low_3Texture;
        }
        else if (Obstacle_type == 3)
        {
            TempForObstacle_Rect.x = ObstacleMove; //
            TempForObstacle_Rect.y = 200;
            TempForObstacle_Rect.h = High_1Surface->h;
            TempForObstacle_Rect.w = High_1Surface->w;
            TempForObstacle = High_1Texture;
        }
        else if (Obstacle_type == 4)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 200;
            TempForObstacle_Rect.h = High_2Surface->h;
            TempForObstacle_Rect.w = High_2Surface->w;
            TempForObstacle = High_2Texture;
        }
        else if (Obstacle_type == 5)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 200;
            TempForObstacle_Rect.h = FourSurface->h;
            TempForObstacle_Rect.w = FourSurface->w;
            TempForObstacle = FourTexture;
        }

        i++;
        if (i % 2 == 0)
        {
            TempForBird = BirdUpTexture;
            TempForBird_Rect = BirdUpRect;
        }
        else if (i % 2 == 1)
        {
            TempForBird = BirdDownTexture;
            TempForBird_Rect = BirdDownRect;
        }
        PRINTSCORE();              // 更新字符
        SDL_RenderClear(Renderer); // 清空画笔
        SDL_RenderCopy(Renderer, PlayBackGroundTexture, NULL, &PlayBackGroundRect);
        SDL_RenderCopy(Renderer, UpBackGroundTexture, NULL, &UpBackGroundRect);
        if (the_jump_from_obstacle)
            SDL_RenderCopy(Renderer, TempForObstacle, NULL, &TempForObstacle_Rect);
        SDL_RenderCopy(Renderer, DinoTexture, NULL, &DinoRect);
        SDL_RenderCopy(Renderer, ScoreTexture, NULL, &ScoreRect);       // 文字
        SDL_RenderCopy(Renderer, BestFontTexture, NULL, &BestFontRect); // 文字
        SDL_RenderCopy(Renderer, TempForBird, NULL, &TempForBird_Rect);
        SDL_RenderPresent(Renderer); // 绘图(跳跃)
        UpGroundMove -= 4 * (speed + 1);
        BackGroundMove -= 10 * (speed + 1);
        ObstacleMove -= 10 * (speed + 1);
        BirdMove -= 20 * (speed + 1);
        Sleep(40);

        t = (jump_now - jump_start) / 100.0;
        a = -1.6 * (V0 * t - 4.8 * pow(t, 2.0)) + 190;

        if (PlayBackGroundRect.x < -860)
            BackGroundMove = 0;
        if (UpBackGroundRect.x < -784)
            UpGroundMove = 0;
        if (((TempForObstacle_Rect.y > DinoRect.y && TempForObstacle_Rect.y < DinoRect.y + DinoRect.h) && (TempForObstacle_Rect.x < Dino_LeftRect.x + Dino_LeftRect.w - 2 * ADD && TempForObstacle_Rect.x > Dino_LeftRect.x) || (TempForObstacle_Rect.y > DinoRect.y && TempForObstacle_Rect.y < DinoRect.y + DinoRect.h) && (TempForObstacle_Rect.x + TempForObstacle_Rect.w < Dino_LeftRect.x + Dino_LeftRect.w && TempForObstacle_Rect.x + TempForObstacle_Rect.w > Dino_LeftRect.x)) && the_jump_from_obstacle)
            BUMP();
        if ((DinoRect.y > BirdDownRect.y && DinoRect.y < BirdDownRect.y + BirdDownRect.h && DinoRect.x + DinoRect.w > BirdDownRect.x && DinoRect.x + DinoRect.w < BirdDownRect.x + BirdDownRect.w) || (DinoRect.y + DinoRect.h > BirdDownRect.y && DinoRect.y + DinoRect.h < BirdDownRect.y + BirdDownRect.h && DinoRect.x + DinoRect.w > BirdDownRect.x && DinoRect.x + DinoRect.w < BirdDownRect.x + BirdDownRect.w) || (DinoRect.y + DinoRect.h > BirdDownRect.y && DinoRect.y + DinoRect.h < BirdDownRect.y + BirdDownRect.h && DinoRect.x > BirdDownRect.x && DinoRect.x < BirdDownRect.x + BirdDownRect.w))
            BUMP();
        SDL_PollEvent(&MainEvent); // 跳跃时吃掉队列内事件
        SDL_PollEvent(&MainEvent); // 跳跃时吃掉队列内事件
    }
    the_jump_from_obstacle = false;
    return;
}
void Obstacle()
{
    srand((unsigned)time(NULL) + 2 * (unsigned)rand());
    random = rand() % 6;
    Obstacle_type = random;
    ObstacleMove = 650;
    for (ObstacleMove = 650; ObstacleMove > -40;)
    {
        now = SDL_GetTicks();
        speed = (now - start) / 100000.0;
        if (Obstacle_type == 0)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 220;
            TempForObstacle_Rect.h = ObstacleSurface->h;
            TempForObstacle_Rect.w = ObstacleSurface->w;
            TempForObstacle = ObstacleTexture;
        }
        else if (Obstacle_type == 1)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 220;
            TempForObstacle_Rect.h = Low_2Surface->h;
            TempForObstacle_Rect.w = Low_2Surface->w;
            TempForObstacle = Low_2Texture;
        }
        else if (Obstacle_type == 2)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 220;
            TempForObstacle_Rect.h = Low_3Surface->h;
            TempForObstacle_Rect.w = Low_3Surface->w;
            TempForObstacle = Low_3Texture;
        }
        else if (Obstacle_type == 3)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 200;
            TempForObstacle_Rect.h = High_1Surface->h;
            TempForObstacle_Rect.w = High_1Surface->w;
            TempForObstacle = High_1Texture;
        }
        else if (Obstacle_type == 4)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 200;
            TempForObstacle_Rect.h = High_2Surface->h;
            TempForObstacle_Rect.w = High_2Surface->w;
            TempForObstacle = High_2Texture;
        }
        else if (Obstacle_type == 5)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 200;
            TempForObstacle_Rect.h = FourSurface->h;
            TempForObstacle_Rect.w = FourSurface->w;
            TempForObstacle = FourTexture;
        }
        PlayBackGroundRect.x = BackGroundMove; // 背景坐标
        PlayBackGroundRect.y = 220;
        PlayBackGroundRect.h = PlayBackGroundSurface->h;
        PlayBackGroundRect.w = PlayBackGroundSurface->w;

        UpBackGroundRect.x = UpGroundMove; // 云朵背景的矩形
        UpBackGroundRect.y = -15;
        UpBackGroundRect.h = UpBackGroundSurface->h;
        UpBackGroundRect.w = UpBackGroundSurface->w;

        i++;
        if (i % 2 == 0)
            Temp = Dino_RightTexture; // 左右脚的过渡
        else if (i % 2 == 1)
            Temp = Dino_LeftTexture;
        PRINTSCORE();              // 更新字符
        SDL_RenderClear(Renderer); // 清空画笔
        SDL_RenderCopy(Renderer, PlayBackGroundTexture, NULL, &PlayBackGroundRect);
        SDL_RenderCopy(Renderer, UpBackGroundTexture, NULL, &UpBackGroundRect);
        SDL_RenderCopy(Renderer, TempForObstacle, NULL, &TempForObstacle_Rect);
        SDL_RenderCopy(Renderer, ScoreTexture, NULL, &ScoreRect);       // 文字
        SDL_RenderCopy(Renderer, BestFontTexture, NULL, &BestFontRect); // 文字
        SDL_RenderCopy(Renderer, Temp, NULL, &Dino_LeftRect);
        SDL_RenderPresent(Renderer); // 绘图(地面)
        BackGroundMove -= 10 * (speed + 1);
        ObstacleMove -= 10 * (speed + 1);
        UpGroundMove -= 4 * (speed + 1);
        Sleep(40);
        if (PlayBackGroundRect.x < -860)
            BackGroundMove = 0;
        if (UpBackGroundRect.x < -784)
            UpGroundMove = 0;
        SDL_PollEvent(&MainEvent);
        switch (MainEvent.type)
        {
        case SDL_QUIT:
            QUIT();
            break;
        case SDL_KEYDOWN:
            switch (MainEvent.key.keysym.sym)
            {
            case SDLK_SPACE:
                the_jump_from_obstacle = true;
                JUMP();
                break;
            case SDLK_UP:
                the_jump_from_obstacle = true;
                JUMP();
                break;
            case SDLK_DOWN:
                the_down_from_obstacle = true;
                DOWN();
                break;
            default:
                SDL_PeepEvents(&MainEvent, 30, SDL_GETEVENT, SDL_FIRSTEVENT, SDL_LASTEVENT);
                break;
            }
            break;
        default:
            break;
        }
        if (TempForObstacle_Rect.x < Dino_LeftRect.x + Dino_LeftRect.w && TempForObstacle_Rect.x > Dino_LeftRect.x) // 判断碰撞
            BUMP();
    }
    return;
}
void DOWN()
{

    while (1) // && (MainEvent.key.keysym.sym == SDLK_SPACE)
    {
        now = SDL_GetTicks();
        speed = (now - start) / 100000.0;
        PlayBackGroundRect.x = BackGroundMove; // 定义有关信息
        PlayBackGroundRect.y = 220;            // 图片的左上角坐标
        PlayBackGroundRect.h = PlayBackGroundSurface->h;
        PlayBackGroundRect.w = PlayBackGroundSurface->w;

        UpBackGroundRect.x = UpGroundMove; // 云朵背景的矩形
        UpBackGroundRect.y = -15;
        UpBackGroundRect.h = UpBackGroundSurface->h;
        UpBackGroundRect.w = UpBackGroundSurface->w;

        BirdUpRect.x = BirdMove; // 小鸟坐标
        BirdUpRect.y = 130 + random;
        BirdUpRect.h = BirdUpSurface->h;
        BirdUpRect.w = BirdUpSurface->w;
        BirdDownRect.x = BirdMove;
        BirdDownRect.y = 138 + random;
        BirdDownRect.h = BirdDownSurface->h;
        BirdDownRect.w = BirdDownSurface->w;
        if (Obstacle_type == 0)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 220;
            TempForObstacle_Rect.h = ObstacleSurface->h;
            TempForObstacle_Rect.w = ObstacleSurface->w;
            TempForObstacle = ObstacleTexture;
        }
        else if (Obstacle_type == 1)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 220;
            TempForObstacle_Rect.h = Low_2Surface->h;
            TempForObstacle_Rect.w = Low_2Surface->w;
            TempForObstacle = Low_2Texture;
        }
        else if (Obstacle_type == 2)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 220;
            TempForObstacle_Rect.h = Low_3Surface->h;
            TempForObstacle_Rect.w = Low_3Surface->w;
            TempForObstacle = Low_3Texture;
        }
        else if (Obstacle_type == 3)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 200;
            TempForObstacle_Rect.h = High_1Surface->h;
            TempForObstacle_Rect.w = High_1Surface->w;
            TempForObstacle = High_1Texture;
        }
        else if (Obstacle_type == 4)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 200;
            TempForObstacle_Rect.h = High_2Surface->h;
            TempForObstacle_Rect.w = High_2Surface->w;
            TempForObstacle = High_2Texture;
        }
        else if (Obstacle_type == 5)
        {
            TempForObstacle_Rect.x = ObstacleMove; // 仙人掌坐标
            TempForObstacle_Rect.y = 200;
            TempForObstacle_Rect.h = FourSurface->h;
            TempForObstacle_Rect.w = FourSurface->w;
            TempForObstacle = FourTexture;
        }
        i++;
        if (i % 2 == 0)
        {
            TempForDown = DinoDown_RightTexture;
            TempForBird = BirdUpTexture;
            TempForBird_Rect = BirdUpRect;

        } // 左右脚的过渡
        else if (i % 2 == 1)
        {
            TempForDown = DinoDown_LeftTexture;
            TempForBird = BirdDownTexture;
            TempForBird_Rect = BirdDownRect;
        }
        PRINTSCORE();              // 更新字符
        SDL_RenderClear(Renderer); // 清空画笔
        SDL_RenderCopy(Renderer, PlayBackGroundTexture, NULL, &PlayBackGroundRect);
        SDL_RenderCopy(Renderer, UpBackGroundTexture, NULL, &UpBackGroundRect);
        if (the_down_from_obstacle)
            SDL_RenderCopy(Renderer, TempForObstacle, NULL, &TempForObstacle_Rect);
        SDL_RenderCopy(Renderer, TempForDown, NULL, &DinoDown_LeftRect);
        SDL_RenderCopy(Renderer, ScoreTexture, NULL, &ScoreRect);       // 文字
        SDL_RenderCopy(Renderer, BestFontTexture, NULL, &BestFontRect); // 文字
        SDL_RenderCopy(Renderer, TempForBird, NULL, &TempForBird_Rect);
        SDL_RenderPresent(Renderer); // 绘图(地面)
        BackGroundMove -= 10 * (speed + 1);
        ObstacleMove -= 10 * (speed + 1);
        UpGroundMove -= 4 * (speed + 1);
        BirdMove -= 20 * (speed + 1);
        Sleep(40);
        if (PlayBackGroundRect.x < -860)
            BackGroundMove = 0;
        if (UpBackGroundRect.x < -784)
            UpGroundMove = 0;
        if (TempForObstacle_Rect.x < DinoDown_LeftRect.x + DinoDown_LeftRect.w && TempForObstacle_Rect.x > DinoDown_LeftRect.x && the_down_from_obstacle) // 判断碰撞
            BUMP();
        if (DinoDown_LeftRect.y < BirdDownRect.y + BirdDownRect.h && BirdDownRect.x < DinoDown_LeftRect.x + DinoDown_LeftRect.w && BirdDownRect.x > DinoDown_LeftRect.x) // 判断碰撞
            BUMP();
        SDL_PollEvent(&MainEvent);
        switch (MainEvent.type)
        {
        case SDL_QUIT:
            QUIT();
            break;
        case SDL_KEYUP:
            switch (MainEvent.key.keysym.sym)
            {
            case SDLK_DOWN:
                goto done;
                break;
            default:
                break;
            }
            break;
        default:
            break;
        }
    }
done:
    the_down_from_obstacle = false;
    return;
}
void Bird()
{

    srand((unsigned)time(NULL) + (unsigned)rand());
    random = rand() % 50;
    for (BirdMove = 650; BirdMove > -40;)
    {
        now = SDL_GetTicks();
        speed = (now - start) / 100000.0;
        PlayBackGroundRect.x = BackGroundMove; // 背景坐标
        PlayBackGroundRect.y = 220;
        PlayBackGroundRect.h = PlayBackGroundSurface->h;
        PlayBackGroundRect.w = PlayBackGroundSurface->w;

        BirdUpRect.x = BirdMove; // 小鸟坐标
        BirdUpRect.y = 130 + random;
        BirdUpRect.h = BirdUpSurface->h;
        BirdUpRect.w = BirdUpSurface->w;
        BirdDownRect.x = BirdMove;
        BirdDownRect.y = 138 + random;
        BirdDownRect.h = BirdDownSurface->h;
        BirdDownRect.w = BirdDownSurface->w;

        UpBackGroundRect.x = UpGroundMove; // 云朵背景的矩形
        UpBackGroundRect.y = -15;
        UpBackGroundRect.h = UpBackGroundSurface->h;
        UpBackGroundRect.w = UpBackGroundSurface->w;

        i++;
        if (i % 2 == 0)
        {
            Temp = Dino_RightTexture;
            TempForBird = BirdUpTexture;
            TempForBird_Rect = BirdUpRect;

        } // 左右脚的过渡
        else if (i % 2 == 1)
        {
            Temp = Dino_LeftTexture;
            TempForBird = BirdDownTexture;
            TempForBird_Rect = BirdDownRect;
        }
        PRINTSCORE();              // 更新字符
        SDL_RenderClear(Renderer); // 清空画笔
        SDL_RenderCopy(Renderer, PlayBackGroundTexture, NULL, &PlayBackGroundRect);
        SDL_RenderCopy(Renderer, UpBackGroundTexture, NULL, &UpBackGroundRect);
        SDL_RenderCopy(Renderer, Temp, NULL, &Dino_LeftRect);
        SDL_RenderCopy(Renderer, TempForBird, NULL, &TempForBird_Rect);
        SDL_RenderCopy(Renderer, ScoreTexture, NULL, &ScoreRect);       // 文字
        SDL_RenderCopy(Renderer, BestFontTexture, NULL, &BestFontRect); // 文字
        SDL_RenderPresent(Renderer);                                    // 绘图
        BackGroundMove -= 10 * (speed + 1);
        BirdMove -= 20 * (speed + 1);
        UpGroundMove -= 4 * (speed + 1);
        Sleep(40);
        if (PlayBackGroundRect.x < -860)
            BackGroundMove = 0;
        if (UpBackGroundRect.x < -784)
            UpGroundMove = 0;
        SDL_PollEvent(&MainEvent);
        switch (MainEvent.type)
        {
        case SDL_QUIT:
            QUIT();
            break;
        case SDL_KEYDOWN:
            switch (MainEvent.key.keysym.sym)
            {
            case SDLK_SPACE:
                JUMP();
                break;
            case SDLK_UP:
                JUMP();
                break;
            case SDLK_DOWN:
                DOWN();
                break;
            default:
                SDL_PeepEvents(&MainEvent, 30, SDL_GETEVENT, SDL_FIRSTEVENT, SDL_LASTEVENT);
                break;
            }
            break;
        default:
            break;
        }
        if ((BirdDownRect.x < Dino_LeftRect.x + Dino_LeftRect.w - ADD && BirdDownRect.x > Dino_LeftRect.x) || (DinoDown_LeftRect.y < BirdDownRect.y + BirdDownRect.h && BirdDownRect.x < DinoDown_LeftRect.x + DinoDown_LeftRect.w && BirdDownRect.x > DinoDown_LeftRect.x)) // 判断碰撞
            BUMP();
    }
    return;
}
void LOAD_BEST()
{
    if ((file_1 = fopen("bestscore.txt", "r+")) == NULL) // 打开文件
    {
        printf("Can not open file!\n");
        QUIT();
    }
    fgets(record_best + 5, 20, file_1);                                             // 文件内容写入字符串数组
    BestFont = TTF_OpenFont("visitor1.ttf", 50);                                    // 打开字体文件，前面是文件名
    BestFontSurface = TTF_RenderUTF8_Blended(BestFont, record_best, BestFontColor); // 从左到右：字体，要打的字符串，字体颜色  存到一个图片里去
    BestFontTexture = SDL_CreateTextureFromSurface(Renderer, BestFontSurface);
    BestFontRect.x = 465; // 画的位置
    BestFontRect.y = 70;
    BestFontRect.w = 180; //(矩形h w控制字体大小)
    BestFontRect.h = 40;
}